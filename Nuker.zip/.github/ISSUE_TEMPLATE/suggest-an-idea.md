---
name: Suggest an idea
about: Got any Ideas to improve Hazard Nuker? Or want to see a feature getting added? Type them here!
title: Hazard Nuker [ENHANCEMENT]
labels: enhancement
assignees: ''

---

**What would you like to see get added/changed to Hazard Nuker**
Please state reasons like why and the benefits with implementing such thing
